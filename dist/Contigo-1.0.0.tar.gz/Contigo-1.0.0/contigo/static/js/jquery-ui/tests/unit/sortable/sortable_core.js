/*
 * sortable_core.js
 */

(function($) {

module("sortable: core");

})(jQuery);
